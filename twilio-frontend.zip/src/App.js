import React from 'react';
function App() {
  return (
    <div>
      <h1>Twilio Web Calling App</h1>
      <p>Frontend is running!</p>
    </div>
  );
}
export default App;